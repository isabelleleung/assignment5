declare module 'handtrackjs';
