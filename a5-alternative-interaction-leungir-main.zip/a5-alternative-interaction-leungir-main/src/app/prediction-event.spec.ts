import { PredictionEvent } from './prediction-event';

describe('PredictionEvent', () => {
  it('should create an instance', () => {
    expect(new PredictionEvent()).toBeTruthy();
  });
});
